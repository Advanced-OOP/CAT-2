/**
*<h2>This file is for implementing the remote interface or extending the implementation class.<h2>
*@version 1.0
*@author Allan Monyoncho
*@author Njoga Harrison 
*@author Josephine Achieng
*/ 
import java.rmi.Remote; 
import java.rmi.RemoteException;  

/**
*<p>Implementing the remote interface CAT2Interface or extending the implementation class.</p>
*@param animation 
*@return void 
*@throws RemoteException  By chance of network issues during remote calls and an exception named RemoteException occurs; throw it.
*/ 
public interface CAT2Interface extends Remote { 
   void animation() throws RemoteException; 
}