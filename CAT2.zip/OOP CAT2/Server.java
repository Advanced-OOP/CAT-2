/**
*<h2>This file contains an RMI server program that implements the remote interface or extend the implementation class.<h2>
*<p> Here, we create a remote object and bind it to the RMIregistry.</p>
*@version 1.0
*@author Allan Monyoncho
*@author Njoga Harrison 
*@author Josephine Achieng
*/
import java.rmi.registry.Registry; 
import java.rmi.registry.LocateRegistry; 
import java.rmi.RemoteException; 
import java.rmi.server.UnicastRemoteObject; 


/**
*<p>Create a server class from where we want invoke the remote object.</p>
*/
public class Server extends CAT2FX { 
   public Server() {} 
   public static void main(String args[]) { 
      try { 
         


         /**
         *<p>Creating a remote object by instantiating the implementation class CAT2FX.</p>
         */ 
         CAT2FX obj = new CAT2FX();
      
         /**
         *<p>Exporting the remote object using the method exportObject() of the class named UnicastRemoteObject which belongs to the package java.rmi.server</p>
         *<p>here we are exporting the remote object to the stub.</p>
         *@param   obj 0
         *@return  The remote object 
         */ 
         CAT2Interface stub = (CAT2Interface) UnicastRemoteObject.exportObject(obj, 0);  
      
         
         /**
         *<p>Binding the remote object (stub) in the registry.</p>
         */ 
         Registry registry = LocateRegistry.getRegistry(); 
         
         registry.bind("CAT2Interface", stub);  
         System.err.println("The requested Server is now Ready! :-)"); 
      } catch (Exception e) { 
         System.err.println("Server exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
   } 
}