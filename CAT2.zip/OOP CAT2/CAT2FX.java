/**
*<h1>This is Documentation for Kaffi's Kitchen Delivery App</h1>
*<h2>This file contains code for the GUI.</h2>
*@version 1.0 
*@author Allan Monyoncho
*@author Njoga Harrison 
*@author Josephine Achieng
*/ 

/**
*<p> javafx imports.</p>
*/
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.collections.FXCollections; 
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.FileInputStream;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.text.Font;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ButtonBase;
import javafx.scene.Group;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Toggle;
import javafx.scene.input.MouseEvent; 
import javafx.scene.paint.Color;
import javafx.event.*;
import javafx.event.EventHandler;
import javafx.event.ActionEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font; 
import javafx.scene.text.FontWeight;
import javafx.scene.control.*;
import javafx.collections.*;
import javafx.scene.control.DatePicker;
import java.time.*;
import java.time.LocalDate;
import javafx.scene.control.Label;
import java.io.FileNotFoundException;
import javafx.scene.canvas.*; 
import java.io.*;
import javafx.scene.*;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.Background;
import javafx.scene.layout.*;
import javafx.beans.value.*;
import javafx.scene.text.*;
import java.sql.*; 
import java.util.*;
import javafx.util.*;
import javafx.stage.Window;



public class CAT2FX extends Application implements CAT2Interface
{

   /**
   *<p> This is a class CAT2FX that inherits from the Application class that is in the javafx.application package.</p>
*<p>JDBC  database URL, password and user .</p>
*@see <a href="mysql://localhost/kaffi">mysql DATABASE</a>
*/
   Connection conn = null; 
   String DB_URL = "jdbc:mysql://localhost/kaffi";   
   String USER = "root"; 
   String  PASS = "";
   


   
   
   public void start(Stage stage) throws Exception
   {
    /**
  *<p>Implementing the start() method of this class.</p>
  *@param stage This is the parameter passed to the start method. The stage is where all the visual parts of the JavaFX application are displayed.
  *@throws Exception JavaFX uses Java's Exception and must extend Exception
  */
      try {
         Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection(DB_URL, USER, PASS);
      }catch(ClassNotFoundException ex) {
            System.out.println("Error: unable to load driver class!");
            System.exit(1);
      }   


    /**
    *<p>Embeding a text into a JavaFX scene by instantiating the class named Text which belongs to a package javafx.scene.shape, 
    *this class is instantiated by passing text to be embedded, in String format.</p>
    */
      Text text1 = new Text("*    are required fields:");
      Text text2 = new Text("*FIRST and SECOND NAME");
      Text text3 = new Text("*SURNAME");
      Text text4 = new Text("*EMAIL");
      Text text5 = new Text("*USERNAME"); 
      Text text6 = new Text("*PASSWORD");       
      Text text8 = new Text("DATE OF BIRTH"); 
      Text text9 = new Text("*P.O BOX");
      Text text10 = new Text("GENDER");
      Text text11 = new Text("KAFFI'S KITCHEN");
      Text text12 = new Text("Already have an Account?");


      /**
      *<p>Creating  TextFields controls by creating an instance of the TextFields class. JavaFX TextField instantiation</p>
      */
      TextField textField1 = new TextField();
      textField1.setStyle("-fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;"); 
      textField1.setPrefWidth(200);      
      textField1.setPrefHeight(35);


      TextField textField2 = new TextField();
      textField2.setStyle(" -fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;");
      textField2.setPrefWidth(200);      
      textField2.setPrefHeight(35);


      TextField textField3 = new TextField();
      textField3.setStyle(" -fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;");
      textField3.setPrefWidth(200);      
      textField3.setPrefHeight(35);


      TextField textField4 = new TextField();
      textField4.setStyle("-fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;");
      textField4.setPrefWidth(200);      
      textField4.setPrefHeight(35);


      PasswordField passwordField1 = new PasswordField();
      passwordField1.setStyle(" -fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;");
      passwordField1.setPrefWidth(200);      
      passwordField1.setPrefHeight(35);
      


      TextField textField7 = new TextField();
      textField7.setStyle(" -fx-font-family: Quicksand; -fx-font-size: 15; -fx-padding: 1,1,1,1; -fx-border-color: grey; -fx-border-width: 2; -fx-border-radius: 1;  -fx-border: gone;  -fx-background-color: NavajoWhite; -fx-text-fill: black;");
      textField7.setPrefWidth(200);      
      textField7.setPrefHeight(35);

      


      /**
      *<p>Creating a DatePicker control via the constructor of the DatePicker class. Here is a JavaFX DatePicker instantiation</p>
      */
      DatePicker datePicker = new DatePicker();
      datePicker.setOnAction
      (e -> 
         {
            LocalDate date = datePicker.getValue();
            System.err.println("Selected date: " + date);
         }
      );



       

       final ToggleGroup toggleGroup1 = new ToggleGroup(); 

       RadioButton male = new RadioButton("Male");     
       male.setToggleGroup(toggleGroup1);
       male.setSelected(true);
       

       RadioButton female = new RadioButton("Female");     
       female.setToggleGroup(toggleGroup1);


       /**
      *<p>JavaFX CheckBox control by the CheckBox constructor. Here is a JavaFX CheckBox instantiation.</p>
      *@return I have Read and Agreed to the Terms and Conditions
      */
       CheckBox checkBox1 = new CheckBox("I have Read and Agreed to the Terms and Conditions");

       checkBox1.setStyle("-fx-font-size:10; -fx-font-weight:bold; -fx-border-color:grey; -fx-border-radius:3px; ");     
        




      Button button1 = new Button("Submit Details");
      Button button2 = new Button("Sign In");
        





      /**
      *<p>Creating a gridpane control via the constructor of the Gridpane class. Here is a JavaFX Gridpane instantiation</p>
      */
      GridPane gridPane = new GridPane();

      /**
      *<p>Setting size for the pane.</p>
      */ 
      gridPane.setMinSize(600, 600);

      /**
      *<p>Setting the padding</p>
      */
      gridPane.setPadding(new Insets(20, 20, 20, 20));

      /**
      *<p>Setting the vertical and horizontal gaps between the columns </p>
      */
      gridPane.setVgap(10);
      gridPane.setHgap(10);

      /**
      *<p>Setting the Grid alignment </p>
      */ 
      gridPane.setAlignment(Pos.CENTER);


      /**
      *<p>Arranging all the nodes in the grid  </p>
      */
      gridPane.add(text11, 0, 0);

      gridPane.add(text1, 0, 1);

      gridPane.add(text2, 0, 2);

      gridPane.add(text3, 1, 2);
      
      gridPane.add(textField1, 0, 3);

      gridPane.add(textField2, 1, 3);

      gridPane.add(text4, 0, 4);

      gridPane.add(text5, 1, 4);

      gridPane.add(textField3, 0, 5);

      gridPane.add(textField4, 1, 5);

      gridPane.add(text6, 0, 6);      

      gridPane.add(passwordField1, 0, 7);       

      gridPane.add(text8, 0, 8);
      
      gridPane.add(datePicker, 0, 9);

      gridPane.add(text9, 1, 6);

      gridPane.add(textField7, 1, 7);

      gridPane.add(text10, 0, 11);

      gridPane.add(male, 0, 12);
      gridPane.add(female, 0, 13);

      gridPane.add(checkBox1, 0, 16);

      gridPane.add(button1, 0, 17);

      gridPane.add(text12, 0, 19);

      gridPane.add(button2, 0, 20);

      


      /**
      *<p>Creating Buttons.</p>
      */
      button1.setStyle("-fx-background-color: inear-gradient(#f2f2f2, #d6d6d6), linear-gradient(#fcfcfc 0%, #d9d9d9 20%, #d6d6d6 100%), linear-gradient(#dddddd 0%, #f6f6f6 50%); -fx-background-radius: 8,7,6; -fx-background-insets: 0,1,2; -fx-text-fill: black;  -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.6) , 5, 0.0 , 0 , 1 );");
      button2.setStyle("-fx-background-color: linear-gradient(#f0ff35, #a9ff00), radial-gradient(center 50% -40%, radius 200%, #b8ee36 45%, #80c800 50%); -fx-background-radius: 6, 5; -fx-background-insets: 0, 1; -fx-effect: dropshadow( three-pass-box , rgba(0,0,0,0.4) , 5, 0.0 , 0 , 1 ); -fx-text-fill: #395306;");
      

         

      /**
      *<p>Creating text styles.</p>
      */ 
      text1.setStyle("-fx-font: normal bold 15px 'script typeface'");
      text2.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text3.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text4.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text5.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text6.setStyle("-fx-font: normal bold 13px 'monospace' ");      
      text8.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text9.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text10.setStyle("-fx-font: normal bold 13px 'monospace' ");
      text11.setStyle("-fx-font: normal bold 40px 'monospace' ");
      text12.setStyle("-fx-font: normal bold 18px 'script typeface' ");



      



     /**
     *<p>creating the save button event handler.</p>
     */
     EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>()
     {
      @Override
      public void handle(MouseEvent e)
      {
        System.out.println("Thank you for registering for Kaffi's Kitchen Delivery Application!");        
        try{ 
              String sql = "INSERT INTO login"+"(name,surname,email,username,password,poBox) VALUES(?,?,?,?,?,?)";
              final PreparedStatement trans = conn.prepareStatement(sql);           
           
              trans.setString(1,textField1.getText());
              trans.setString(2,textField2.getText());
              trans.setString(3,textField3.getText());
              trans.setString(4,textField4.getText());
              trans.setString(5,passwordField1.getText());              
              trans.setString(6,textField7.getText());
              trans.executeUpdate();
            }


            catch(SQLException se)
            {
               se.printStackTrace();
            }


            if(textField1.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter your first and second name");
            return;
        }
        if(textField2.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter your surname");
            return;
        }
        if(textField3.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter your email");
            return;
        }

        if(textField4.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter a username");
            return;
        }

        if(passwordField1.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter a password");
            return;
        }

        if(textField7.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
            "Form Error!", "Please enter a postal address");
            return;
        }

        showAlert(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), 
        "Registration Successful!", "Welcome " + textField2.getText() + "   Proceed to Sign In?");



        }

        private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

     };
     
     button1.addEventHandler(MouseEvent.MOUSE_CLICKED,eventHandler); 





     /**
     *<p>Creating an event handler that pops up a dialog whenever the user fails to fil in any of the required textfields</p>
     */
     EventHandler<MouseEvent> eventHandler1 = new EventHandler<MouseEvent>()
     {
      @Override
      public void handle(MouseEvent e)
      {
        showAlert(Alert.AlertType.INFORMATION, gridPane.getScene().getWindow(), 
        "Works in Progress...", "This feature will be available soon   :-) ");
      }

        private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }

      };
      button2.addEventHandler(MouseEvent.MOUSE_CLICKED,eventHandler1);



       





      gridPane.setStyle("-fx-background-color: LightSalmon");


     /**
     *<p>A Scene class of the package javafx.scene. A scene is created by instantiating the class as shown in the following code block.
       *  A gridpane is passed to the constructor of the scene class.</p>
     */
      Scene scene = new Scene(gridPane);

      stage.setTitle("Kaffi's Kitchen Delivery");

     /**
     *@see Image
     */
      stage.getIcons().add(new Image("file:CAT2Image.png"));

      /**
      *<p>Adding scene to the stage .</p>
      */
      stage.setScene(scene);


      /**
      *<p>Displaying the contents of the stage.</p>
      */
      stage.show();
   }


   private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
  

   
  
   public void animation() 
    {
       /**
       *<p> Launch the JavaFX application by calling the static method launch() of the Application class.</p>
       */
       launch();
    } 

}