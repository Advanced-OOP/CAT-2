/**
*<h2>This file contains a client program in it. <h2>
*<p>The remote object is fetched and the required method using this object is invoked. </p>
*@version 1.0
*@author Allan Monyoncho
*@author Njoga Harrison 
*@author Josephine Achieng
*/
import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry;
import java.rmi.registry.*;  


/**
*<p>Createing a client class from where we intend to invoke the remote object.</p>
*/
public class Client { 
   private Client() {} 
   public static void main(String[] args) {  
      try { 
         

         /**
         *<p>Geting the RMI registry using the getRegistry() method of the LocateRegistry class which belongs to the package java.rmi.registry.</p>
         *@param  null
         *@return The RMI registry
         */
         Registry registry = LocateRegistry.getRegistry(null); 
    
         // Looking up the registry for the remote object 
         CAT2Interface stub = (CAT2Interface) registry.lookup("CAT2Interface"); 
         
         /**
         *<p>Calling the required method using the obtained remote object.</p>
         */  
         stub.animation(); 
         
         System.out.println("Remote method invoked"); 
      } catch (Exception e) {
         System.err.println("Client exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
   } 
}